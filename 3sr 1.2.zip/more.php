<!DOCTYPE html>
<html lang="ar">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>مركز تحميل عصر الوابكا</title>

    <!-- استايل البوت ستراب -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

<style>
    body { padding-top: 1px; }
    </style>
<?php include('inc/styled.php');?>

        <link rel="stylesheet" href="css/main.css">
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="js/jquery-1.8.2.min.js"></script>
        <script src="js/jquery.validate.min.js"></script>
        <script src="js/main.js"></script>

    <!-- تخصيص الاستايل -->

    <!-- التجاوب -->
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<script src="http://cdn-ye.yn.lt/3sr/s1.js"></script>
<script async="true" src="http://cdn-ye.yn.lt/3sr/s2.js"></script>
    <![endif]-->
<?php include('inc/rights.php');?>
</head>

<body>
    

            <!-- بداية روابط القائمة -->
       
 
            <!-- /نهاية روابط القائمة -->


 <form id="login-form" class="login-form" name="form1">


<div class="container">
 <div class="panel-body"> 
<ul class="breadcrumb"> <li><a href="/">البدايـــة</a></li> <li class="active">المزيــد</li> </ul> </div>


            <div class="alj1">

<div class="list-group"> <a href="ask.php" class="list-group-item"> <h4 class="list-group-item-heading">اسئلــة واجابــات</h4> <p class="list-group-item-text">هنا تستطيع بعض الاسئلة المهمة التي يجب عليك معرفتها</p> </a> </div>

               
</div>
<hr/>
          </div>

       
    <!-- /نهاية الصفحة -->


  <!-- بداية الفوتر -->
<span class="alj1">
<?php include('inc/footer.php'); ?>
</span>
  <!-- /نهاية الفوتر -->

    <!-- الجيكويري -->
    <script src="js/jquery.js"></script>

    <!-- البوت ستراب -->
    <script src="js/bootstrap.min.js"></script>

</form>
</body>

</html>
