<!DOCTYPE html>
<html lang="ar">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>اسئلة واجابات | عصر الوابكا</title>

    <!-- استايل البوت ستراب -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
<link href="http://alamera.ga/styles.css" rel="stylesheet" type="text/css"/>

<style>
    body { padding-top: 1px; }
    </style>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>ادمن الصور : عصر الوابكا</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

        <link rel="stylesheet" href="css/main.css">
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="js/jquery-1.8.2.min.js"></script>
        <script src="js/jquery.validate.min.js"></script>
        <script src="js/main.js"></script>

    <!-- تخصيص الاستايل -->

    <!-- التجاوب -->
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<script src="http://cdn-ye.yn.lt/3sr/s1.js"></script>
<script async="true" src="http://cdn-ye.yn.lt/3sr/s2.js"></script>
    <![endif]-->
<?php include('inc/rights.php');?>
</head>

<body>
    

            <!-- بداية روابط القائمة -->
       
 
            <!-- /نهاية روابط القائمة -->


 <form id="login-form" class="login-form" name="form1">


<div class="container">
<div class="alert alert-dismissible alert-warning"> <button type="button" class="close" data-dismiss="alert">&times;</button> <h4>تنبيـــة!</h4> <p color="red">المركز وضع للتسهيل عليكم وليس لاحتكاركم</p> </div>

 <div class="panel-body"> 
<ul class="breadcrumb"> <li><a href="/">البدايـــة</a></li> <li><a href="more.php">المزيـــد</a></li><li class="active">اسئــلة واجابــات</li> </ul> </div>

            <div class="alj1">

<div class="list-group"> <a href="#" class="list-group-item"> <h4 class="list-group-item-heading">هل ستضر الصور الجنسية بالشات؟</h4> <p class="list-group-item-text">لا.. اطلاقا لان المركز يعمل على سرفر خارجي ليس له صله بشبكة وابكا ولا تستطيع وابكا السيطره علية</p> </a> <a href="#" class="list-group-item"> <h4 class="list-group-item-heading">هل يوجد مساحة محدده للرفع؟</h4> <p class="list-group-item-text">ليس هناك مساحه مخصصه ونحن نستضيف المركز على استضافه غير محدوده وبامكانك رفع صور لا حتى 10 ميجا للصوره الواحده </p> </a> 
 <a href="#" class="list-group-item"> <h4 class="list-group-item-heading">كم ستبقى الصوره محفوظه بالمركز؟</h4> <p class="list-group-item-text">لان المركز وضع فقط للتسهيل على اعضاء الشات رفع صورهم بعد رفع الصوره للعضو لن يكون هناك داع للصوره وسيتم حذفها بعد مدة اقصاها شهر وادناها 10 ايام</p> </a> 
 <a href="#" class="list-group-item"> <h4 class="list-group-item-heading">كيف نثق بسرفراتكم؟</h4> <p class="list-group-item-text">نحن لا نعطي اي ضمانات لاننا نقدم الخدمه لكم مجانا ونحن نعد بتقديم افضل خدمه ولا ننكر ان هناك مشاكل نادرا تحصل عالسرفر ويعود بعد اصلاح الخطأ للعمل بشكل طبيعي</p> </a> 
 <a href="#" class="list-group-item"> <h4 class="list-group-item-heading">هل استطيع مسح الشات عن طريق المركز؟</h4> <p class="list-group-item-text">لا .. لن تسطيع مسح او تعديل او اي شي في الشات لانه المركز ليس له تأثير عالشات ويعمل بقواعد بيانات منفصله ونطاق منفصل ولوحة تحكم منفصله لذا لا يوجد خوف</p> </a> 
 <a href="#" class="list-group-item"> <h4 class="list-group-item-heading">كيف احصل على مركز مجاني؟</h4> <p class="list-group-item-text">تسطيع الحصول على مركز مجاني بالدخول لموقع (عصر الوابكا) ومراسلة المدير او كتابة موضوع وسيتم التنفيذ باسرع وقت</p> </a> 
 <a href="#" class="list-group-item"> <h4 class="list-group-item-heading">اين اجد الدعم الفني في حال طلبها؟</h4> <p class="list-group-item-text">تجد الدعم الفني في موقع عصر الوابكا او مراسلة الاداره على البريد الالكتروني او المحادثه المباشره </p> </a> </div>

               
</div>
<hr/>
          </div>

       
    <!-- /نهاية الصفحة -->


  <!-- بداية الفوتر -->
<span class="alj1">
<?php include('inc/footer.php'); ?>
</span>
  <!-- /نهاية الفوتر -->

    <!-- الجيكويري -->
    <script src="js/jquery.js"></script>

    <!-- البوت ستراب -->
    <script src="js/bootstrap.min.js"></script>

</form>
</body>

</html>
