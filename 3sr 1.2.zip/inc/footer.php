<?php include('inc/rights.php');?>
<div class="container">
    <div id="footer" class="list-group-item">
 <p> <a href="<?php echo $urlchat?>">مركز <font color="red"><?php echo $namesite?></font></a></p>
        <p class="text-muted"> <a href="http://aljup.com"><font color="green">تطوير محمد الجيلاني (aljup.com)</font></a>
<br>زوار الموقع: <font color="red"><?php include('inc/counter.txt');?></font> الاصدار V<font color="red"><?php echo $v?></font></p>
      </div>
<p align="center">
<a href="/?<?php include('inc/counter.txt');?>"><font color="blue">الصفحــة الرئيسيـة</font></a></p>
    </div>