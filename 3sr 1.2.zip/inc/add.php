<small>
           <a href="add.php" button type="button" class="btn btn-success">اضف صورة</a>
<a href="<?php echo $urlchat?>" button type="button" class="btn btn-danger">عودة للشـات</a>
<a href="more.php" button type="button" class="btn btn-primary">المـزيــد</a> 
</small>
           
