<!DOCTYPE html>
<html lang="ar">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>مركز تحميل عصر الوابكا</title>

    <!-- استايل البوت ستراب -->
<link href="http://alamera.ga/styles.css" rel="stylesheet" type="text/css"/>
  
</head>

<body>
    

<iframe src="http://regup.ga/update_file/index.php#responses" width="320" height="300" frameborder="0" marginheight="0" marginwidth="0">جارٍ التحميل...</iframe>
</body>

</html>
